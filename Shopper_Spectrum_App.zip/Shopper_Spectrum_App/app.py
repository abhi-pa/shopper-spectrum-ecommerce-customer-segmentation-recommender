"""
Shopper Spectrum - Streamlit App
Customer Segmentation & Product Recommendation System

Run with: streamlit run app.py
Requires the 'model_artifacts/' folder (kmeans_model.pkl, scaler.pkl,
segment_labels.pkl, product_similarity_lookup.pkl, product_list.pkl)
to be in the same directory as this file.
"""

import streamlit as st
import pickle
import numpy as np
import pandas as pd
import os

# ----------------------------------------------------------------------------
# Page configuration
# ----------------------------------------------------------------------------
st.set_page_config(
    page_title="Shopper Spectrum",
    page_icon="🛒",
    layout="wide"
)

ARTIFACT_DIR = "model_artifacts"


# ----------------------------------------------------------------------------
# Cached loaders - with exception handling so the app fails gracefully
# rather than crashing if an artifact is missing/corrupted.
# ----------------------------------------------------------------------------
@st.cache_resource
def load_artifact(filename):
    path = os.path.join(ARTIFACT_DIR, filename)
    try:
        with open(path, "rb") as f:
            return pickle.load(f)
    except FileNotFoundError:
        st.error(
            f"Required file '{filename}' was not found in the '{ARTIFACT_DIR}/' folder. "
            "Please make sure all model artifacts are present alongside this app."
        )
        st.stop()
    except Exception as e:
        st.error(f"Error loading '{filename}': {e}")
        st.stop()


kmeans_model = load_artifact("kmeans_model.pkl")
scaler = load_artifact("scaler.pkl")
segment_labels = load_artifact("segment_labels.pkl")
product_similarity_lookup = load_artifact("product_similarity_lookup.pkl")
product_list = load_artifact("product_list.pkl")


# ----------------------------------------------------------------------------
# Core functions
# ----------------------------------------------------------------------------
def predict_segment(recency, frequency, monetary):
    """
    Takes raw RFM values for a customer, applies the same log-transform +
    scaling pipeline used during training, and returns the predicted
    cluster ID and its business-friendly segment label.
    """
    try:
        raw = np.array([[recency, frequency, monetary]], dtype=float)
        log_transformed = np.log1p(raw)
        log_df = pd.DataFrame(log_transformed, columns=["Recency_log", "Frequency_log", "Monetary_log"])
        scaled = scaler.transform(log_df)
        cluster_id = int(kmeans_model.predict(scaled)[0])
        label = segment_labels.get(cluster_id, "Unknown")
        return cluster_id, label
    except Exception as e:
        return None, f"Error during prediction: {e}"


def recommend_products(product_name, n=5):
    """
    Looks up the top-n most similar products for a given product name
    using the precomputed cosine-similarity lookup table.
    """
    if product_name not in product_similarity_lookup:
        return None
    return product_similarity_lookup[product_name][:n]


# Segment descriptions shown to the business user for context
SEGMENT_DESCRIPTIONS = {
    "High-Value": "Recent, frequent, and high-spending customers. Prioritize loyalty rewards and VIP treatment.",
    "Regular": "Steady, dependable customers with moderate frequency and spend. Good candidates for upsell offers.",
    "Occasional": "Infrequent buyers with lower spend. Consider engagement campaigns to increase purchase frequency.",
    "At-Risk": "Customers who haven't purchased recently. Prioritize win-back/retention campaigns before they churn.",
}

SEGMENT_COLORS = {
    "High-Value": "🟢",
    "Regular": "🔵",
    "Occasional": "🟡",
    "At-Risk": "🔴",
}


# ----------------------------------------------------------------------------
# Sidebar navigation
# ----------------------------------------------------------------------------
st.sidebar.title("🛒 Shopper Spectrum")
st.sidebar.markdown("Customer Segmentation & Product Recommendations")
page = st.sidebar.radio(
    "Choose a module:",
    ["🏠 Home", "🎁 Product Recommendation", "👥 Customer Segmentation"]
)

st.sidebar.markdown("---")
st.sidebar.caption(
    "Built with K-Means clustering (RFM analysis) and item-based "
    "collaborative filtering (cosine similarity)."
)


# ----------------------------------------------------------------------------
# Page: Home
# ----------------------------------------------------------------------------
if page == "🏠 Home":
    st.title("🛒 Shopper Spectrum")
    st.subheader("Customer Segmentation and Product Recommendations in E-Commerce")

    st.markdown(
        """
        Welcome! This app has two tools, available from the sidebar:

        ### 🎁 Product Recommendation
        Enter a product name to get the **top 5 most similar products**,
        based on what other customers tend to buy together.

        ### 👥 Customer Segmentation
        Enter a customer's **Recency**, **Frequency**, and **Monetary** values
        to instantly predict which customer segment they belong to -
        **High-Value**, **Regular**, **Occasional**, or **At-Risk**.
        """
    )

    col1, col2, col3, col4 = st.columns(4)
    for col, seg in zip([col1, col2, col3, col4], ["High-Value", "Regular", "Occasional", "At-Risk"]):
        with col:
            st.metric(label=f"{SEGMENT_COLORS[seg]} {seg}", value="")
            st.caption(SEGMENT_DESCRIPTIONS[seg])


# ----------------------------------------------------------------------------
# Page: Product Recommendation
# ----------------------------------------------------------------------------
elif page == "🎁 Product Recommendation":
    st.title("🎁 Product Recommendation")
    st.markdown("Select a product to see the 5 most similar products, based on customer purchase patterns.")

    product_name = st.selectbox(
        "Choose a product:",
        options=product_list,
        index=None,
        placeholder="Start typing a product name..."
    )

    if st.button("Get Recommendations", type="primary"):
        if product_name is None:
            st.warning("Please select a product first.")
        else:
            with st.spinner("Finding similar products..."):
                recommendations = recommend_products(product_name, n=5)

            if recommendations is None:
                st.error(f"'{product_name}' was not found in the catalog. Please choose a different product.")
            else:
                st.success(f"Top 5 products similar to **{product_name}**:")
                rec_df = pd.DataFrame(recommendations, columns=["Product", "Similarity Score"])
                rec_df["Similarity Score"] = rec_df["Similarity Score"].round(3)
                rec_df.index = rec_df.index + 1

                for i, row in rec_df.iterrows():
                    col1, col2 = st.columns([4, 1])
                    with col1:
                        st.markdown(f"**{i}. {row['Product']}**")
                    with col2:
                        st.markdown(f"`{row['Similarity Score']}`")

                st.bar_chart(rec_df.set_index("Product")["Similarity Score"])


# ----------------------------------------------------------------------------
# Page: Customer Segmentation
# ----------------------------------------------------------------------------
elif page == "👥 Customer Segmentation":
    st.title("👥 Customer Segmentation")
    st.markdown("Enter a customer's RFM values to predict their segment.")

    col1, col2, col3 = st.columns(3)
    with col1:
        recency = st.number_input(
            "Recency (days since last purchase)",
            min_value=0, max_value=2000, value=30, step=1,
            help="Number of days since the customer's most recent purchase."
        )
    with col2:
        frequency = st.number_input(
            "Frequency (number of purchases)",
            min_value=1, max_value=1000, value=5, step=1,
            help="Total number of distinct invoices/orders placed by the customer."
        )
    with col3:
        monetary = st.number_input(
            "Monetary (total spend, GBP)",
            min_value=0.0, max_value=1_000_000.0, value=500.0, step=10.0,
            help="Total amount spent by the customer across all orders."
        )

    if st.button("Predict Segment", type="primary"):
        cluster_id, label = predict_segment(recency, frequency, monetary)

        if cluster_id is None:
            st.error(label)  # label holds the error message in this case
        else:
            st.markdown("---")
            st.subheader(f"{SEGMENT_COLORS.get(label, '')} Predicted Segment: **{label}**")
            st.info(SEGMENT_DESCRIPTIONS.get(label, "No description available."))

            with st.expander("See input values used"):
                st.write(
                    pd.DataFrame(
                        {"Recency (days)": [recency], "Frequency (orders)": [frequency], "Monetary (GBP)": [monetary]}
                    )
                )
